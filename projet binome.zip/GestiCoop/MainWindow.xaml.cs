using System.Windows;
using GestiCoop.Views;

namespace GestiCoop
{
    public partial class MainWindow : Window
    {
        public MainWindow(string nom, string role)
        {
            InitializeComponent();
            txtUtilisateur.Text = nom + " (" + role + ")";
        }

        private void BtnDeconnexion_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow login = new LoginWindow();
            login.Show();
            Close();
        }
    }
}
