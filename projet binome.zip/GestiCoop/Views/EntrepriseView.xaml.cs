using System.Windows.Controls;
using GestiCoop.ViewModels;

namespace GestiCoop.Views
{
    public partial class EntrepriseView : UserControl
    {
        public EntrepriseView()
        {
            InitializeComponent();
            DataContext = new EntrepriseViewModel();
        }
    }
}
