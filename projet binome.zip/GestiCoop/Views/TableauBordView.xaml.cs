using System.Windows;
using System.Windows.Controls;
using GestiCoop.ViewModels;

namespace GestiCoop.Views
{
    public partial class TableauBordView : UserControl
    {
        public TableauBordView()
        {
            InitializeComponent();
        }

        // Loaded se déclenche chaque fois qu'on revient sur l'onglet :
        // on recrée le ViewModel pour que les chiffres soient à jour
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            DataContext = new TableauBordViewModel();
        }
    }
}
