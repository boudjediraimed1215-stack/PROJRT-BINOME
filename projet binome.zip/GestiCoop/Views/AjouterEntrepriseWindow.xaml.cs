using System.Windows;
using GestiCoop.ViewModels;

namespace GestiCoop.Views
{
    public partial class AjouterEntrepriseWindow : Window
    {
        public AjouterEntrepriseWindow()
        {
            InitializeComponent();
            // Le DataContext est donné par EntrepriseViewModel avant ShowDialog()
        }

        private void BtnEnregistrer_Click(object sender, RoutedEventArgs e)
        {
            AjouterEntrepriseViewModel vm = (AjouterEntrepriseViewModel)DataContext;
            if (vm.Valider())
            {
                DialogResult = true;   // ferme la fenêtre, ShowDialog() retourne true
            }
        }
    }
}
