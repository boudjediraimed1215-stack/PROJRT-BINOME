using System.Windows.Controls;
using GestiCoop.ViewModels;

namespace GestiCoop.Views
{
    public partial class OffreStageView : UserControl
    {
        public OffreStageView()
        {
            InitializeComponent();
            DataContext = new OffreViewModel();
        }
    }
}
