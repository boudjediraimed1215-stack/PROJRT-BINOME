using System.Windows;
using GestiCoop.ViewModels;

namespace GestiCoop.Views
{
    public partial class LoginWindow : Window
    {
        private LoginViewModel vm = new LoginViewModel();

        public LoginWindow()
        {
            InitializeComponent();
            DataContext = vm;
        }

        private void BtnConnecter_Click(object sender, RoutedEventArgs e)
        {
            // On lit le mot de passe ici car PasswordBox.Password n'accepte pas de Binding
            if (vm.Connecter(txtMotDePasse.Password))
            {
                MainWindow fenetre = new MainWindow(vm.NomConnecte, vm.RoleConnecte);
                fenetre.Show();
                Close();
            }
        }
    }
}
