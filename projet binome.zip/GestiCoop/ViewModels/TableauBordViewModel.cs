using System.Collections.ObjectModel;
using GestiCoop.Models;

namespace GestiCoop.ViewModels
{
    // Écran 2 — Tableau de bord (les chiffres sont calculés à partir de Donnees)
    public class TableauBordViewModel : ViewModelBase
    {
        public int NbEntreprises { get; set; }
        public int NbOffresOuvertes { get; set; }
        public int NbEtudiants { get; set; }
        public int NbCandidatures { get; set; }

        public ObservableCollection<CandidatureModel> Candidatures { get; set; }
        public ObservableCollection<string> OffresParSecteur { get; set; }

        public TableauBordViewModel()
        {
            NbEntreprises = Donnees.Entreprises.Count;
            NbEtudiants = Donnees.Etudiants.Count;
            NbCandidatures = Donnees.Candidatures.Count;

            NbOffresOuvertes = 0;
            foreach (OffreStageModel o in Donnees.Offres)
            {
                if (o.Statut == StatutOffre.Ouverte)
                {
                    NbOffresOuvertes++;
                }
            }

            Candidatures = new ObservableCollection<CandidatureModel>(Donnees.Candidatures);

            // Compter les offres de chaque secteur
            OffresParSecteur = new ObservableCollection<string>();
            foreach (string secteur in Donnees.Secteurs)
            {
                int nombre = 0;
                foreach (OffreStageModel o in Donnees.Offres)
                {
                    if (o.Entreprise.Secteur == secteur)
                    {
                        nombre++;
                    }
                }
                OffresParSecteur.Add(secteur + " : " + nombre);
            }
        }
    }
}
