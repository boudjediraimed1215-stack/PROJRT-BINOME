namespace GestiCoop.ViewModels
{
    // Écran 1 — Connexion
    public class LoginViewModel : ViewModelBase
    {
        private bool isEtudiant;
        public bool IsEtudiant
        {
            get { return isEtudiant; }
            set { Set(ref isEtudiant, value); }
        }

        private bool isEntreprise;
        public bool IsEntreprise
        {
            get { return isEntreprise; }
            set { Set(ref isEntreprise, value); }
        }

        private bool isCoordonnateur = true;
        public bool IsCoordonnateur
        {
            get { return isCoordonnateur; }
            set { Set(ref isCoordonnateur, value); }
        }

        private string courriel = "";
        public string Courriel
        {
            get { return courriel; }
            set { Set(ref courriel, value); }
        }

        private string messageErreur = "";
        public string MessageErreur
        {
            get { return messageErreur; }
            set { Set(ref messageErreur, value); }
        }

        // Rempli quand la connexion réussit
        public string NomConnecte { get; set; }
        public string RoleConnecte { get; set; }

        // Le mot de passe vient du code-behind (un PasswordBox n'accepte pas de Binding)
        public bool Connecter(string motDePasse)
        {
            if (Courriel == "" || motDePasse == "")
            {
                MessageErreur = "Veuillez remplir le courriel et le mot de passe.";
                return false;
            }

            if (IsCoordonnateur && Courriel == "m.tremblay@lacite.edu" && motDePasse == "coop2025")
            {
                NomConnecte = "M. Tremblay";
                RoleConnecte = "Coordonnateur";
                return true;
            }
            if (IsEtudiant && Courriel == "yasmine.c@lacite.edu" && motDePasse == "etud2025")
            {
                NomConnecte = "Yasmine Choudhury";
                RoleConnecte = "Étudiant";
                return true;
            }
            if (IsEntreprise && Courriel == "rh@techsolutions.ca" && motDePasse == "entr2025")
            {
                NomConnecte = "Tech Solutions Inc.";
                RoleConnecte = "Entreprise";
                return true;
            }

            MessageErreur = "Courriel ou mot de passe invalide.";
            return false;
        }
    }
}
