using GestiCoop.Models;

namespace GestiCoop.ViewModels
{
    // Écran 4 — Formulaire Ajouter / Modifier une entreprise
    public class AjouterEntrepriseViewModel : ViewModelBase
    {
        private EntrepriseModel entreprise;   // null = ajout, sinon = modification

        public string TitreFenetre { get; set; }

        public List<string> Secteurs { get; set; } = Donnees.Secteurs;
        public List<StatutEntreprise> Statuts { get; set; } = new List<StatutEntreprise>
        {
            StatutEntreprise.Active, StatutEntreprise.Archivée
        };

        private string nom = "";
        public string Nom { get { return nom; } set { Set(ref nom, value); } }

        private string secteur;
        public string Secteur { get { return secteur; } set { Set(ref secteur, value); } }

        private string adresse = "";
        public string Adresse { get { return adresse; } set { Set(ref adresse, value); } }

        private string contactNom = "";
        public string ContactNom { get { return contactNom; } set { Set(ref contactNom, value); } }

        private string contactCourriel = "";
        public string ContactCourriel { get { return contactCourriel; } set { Set(ref contactCourriel, value); } }

        private string contactTelephone = "";
        public string ContactTelephone { get { return contactTelephone; } set { Set(ref contactTelephone, value); } }

        private string contactTitre = "";
        public string ContactTitre { get { return contactTitre; } set { Set(ref contactTitre, value); } }

        // string pour pouvoir vérifier avec int.TryParse
        private string nombrePostes = "1";
        public string NombrePostes { get { return nombrePostes; } set { Set(ref nombrePostes, value); } }

        private DateTime dateLimite = DateTime.Today.AddMonths(1);
        public DateTime DateLimite { get { return dateLimite; } set { Set(ref dateLimite, value); } }

        private StatutEntreprise statut = StatutEntreprise.Active;
        public StatutEntreprise Statut { get { return statut; } set { Set(ref statut, value); } }

        private string messageErreur = "";
        public string MessageErreur { get { return messageErreur; } set { Set(ref messageErreur, value); } }

        public AjouterEntrepriseViewModel(EntrepriseModel entreprise)
        {
            this.entreprise = entreprise;

            if (entreprise == null)
            {
                TitreFenetre = "Ajouter une entreprise";
            }
            else
            {
                // Modification : on remplit le formulaire avec les valeurs existantes
                TitreFenetre = "Modifier une entreprise";
                Nom = entreprise.Nom;
                Secteur = entreprise.Secteur;
                Adresse = entreprise.Adresse;
                ContactNom = entreprise.ContactNom;
                ContactCourriel = entreprise.ContactCourriel;
                ContactTelephone = entreprise.ContactTelephone;
                ContactTitre = entreprise.ContactTitre;
                NombrePostes = entreprise.NombrePostes.ToString();
                DateLimite = entreprise.DateLimite;
                Statut = entreprise.Statut;
            }
        }

        // Retourne true si tout est valide et enregistré
        public bool Valider()
        {
            int postes;

            if (Nom == "" || Secteur == null || ContactNom == "" || ContactCourriel == "")
            {
                MessageErreur = "Veuillez remplir les champs obligatoires (*).";
                return false;
            }
            if (!ContactCourriel.Contains("@"))
            {
                MessageErreur = "Le courriel n'est pas valide.";
                return false;
            }
            if (!int.TryParse(NombrePostes, out postes) || postes < 1)
            {
                MessageErreur = "Le nombre de postes doit être un nombre plus grand que 0.";
                return false;
            }

            if (entreprise == null)
            {
                entreprise = new EntrepriseModel();
                Donnees.Entreprises.Add(entreprise);
            }

            entreprise.Nom = Nom;
            entreprise.Secteur = Secteur;
            entreprise.Adresse = Adresse;
            entreprise.ContactNom = ContactNom;
            entreprise.ContactCourriel = ContactCourriel;
            entreprise.ContactTelephone = ContactTelephone;
            entreprise.ContactTitre = ContactTitre;
            entreprise.NombrePostes = postes;
            entreprise.DateLimite = DateLimite;
            entreprise.Statut = Statut;
            return true;
        }
    }
}
