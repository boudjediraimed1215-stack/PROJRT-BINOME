using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using GestiCoop.Models;
using GestiCoop.Views;

namespace GestiCoop.ViewModels
{
    // Écran 3 — Liste des entreprises
    public class EntrepriseViewModel : ViewModelBase
    {
        public ObservableCollection<EntrepriseModel> Entreprises { get; set; } = new ObservableCollection<EntrepriseModel>();

        private EntrepriseModel entrepriseSelectionnee;
        public EntrepriseModel EntrepriseSelectionnee
        {
            get { return entrepriseSelectionnee; }
            set { Set(ref entrepriseSelectionnee, value); }
        }

        private string recherche = "";
        public string Recherche
        {
            get { return recherche; }
            set
            {
                Set(ref recherche, value);
                Charger();   // on refiltre à chaque lettre
            }
        }

        public ICommand AjouterCommand { get; set; }
        public ICommand ModifierCommand { get; set; }
        public ICommand SupprimerCommand { get; set; }

        public EntrepriseViewModel()
        {
            AjouterCommand = new RelayCommand(p => Ajouter());
            ModifierCommand = new RelayCommand(p => Modifier(), p => EntrepriseSelectionnee != null);
            SupprimerCommand = new RelayCommand(p => Supprimer(), p => EntrepriseSelectionnee != null);
            Charger();
        }

        // Copie la List du Model dans l'ObservableCollection (en filtrant par nom)
        private void Charger()
        {
            Entreprises.Clear();
            foreach (EntrepriseModel e in Donnees.Entreprises)
            {
                if (e.Nom.ToLower().Contains(Recherche.ToLower()))
                {
                    Entreprises.Add(e);
                }
            }
        }

        private void Ajouter()
        {
            AjouterEntrepriseWindow fenetre = new AjouterEntrepriseWindow();
            fenetre.DataContext = new AjouterEntrepriseViewModel(null);
            if (fenetre.ShowDialog() == true)
            {
                Charger();
            }
        }

        private void Modifier()
        {
            AjouterEntrepriseWindow fenetre = new AjouterEntrepriseWindow();
            fenetre.DataContext = new AjouterEntrepriseViewModel(EntrepriseSelectionnee);
            if (fenetre.ShowDialog() == true)
            {
                Charger();
            }
        }

        private void Supprimer()
        {
            MessageBoxResult reponse = MessageBox.Show(
                "Supprimer " + EntrepriseSelectionnee.Nom + " et ses offres ?",
                "Confirmation", MessageBoxButton.YesNo);

            if (reponse == MessageBoxResult.Yes)
            {
                Donnees.SupprimerEntreprise(EntrepriseSelectionnee);
                Charger();
            }
        }
    }
}
