using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using GestiCoop.Models;

namespace GestiCoop.ViewModels
{
    // Écran 5 — Liste des offres de stage
    public class OffreViewModel : ViewModelBase
    {
        public ObservableCollection<OffreStageModel> Offres { get; set; } = new ObservableCollection<OffreStageModel>();

        public List<string> StatutsFiltre { get; set; } = new List<string> { "Tous", "Ouverte", "Fermée" };

        private OffreStageModel offreSelectionnee;
        public OffreStageModel OffreSelectionnee
        {
            get { return offreSelectionnee; }
            set { Set(ref offreSelectionnee, value); }
        }

        private string recherche = "";
        public string Recherche
        {
            get { return recherche; }
            set { Set(ref recherche, value); Charger(); }
        }

        private string statutFiltre = "Tous";
        public string StatutFiltre
        {
            get { return statutFiltre; }
            set { Set(ref statutFiltre, value); Charger(); }
        }

        private string texteCompteur = "";
        public string TexteCompteur
        {
            get { return texteCompteur; }
            set { Set(ref texteCompteur, value); }
        }

        public ICommand VoirCommand { get; set; }
        public ICommand SupprimerCommand { get; set; }

        public OffreViewModel()
        {
            VoirCommand = new RelayCommand(p => Voir(), p => OffreSelectionnee != null);
            SupprimerCommand = new RelayCommand(p => Supprimer(), p => OffreSelectionnee != null);
            Charger();
        }

        private void Charger()
        {
            Offres.Clear();
            foreach (OffreStageModel o in Donnees.Offres)
            {
                bool bonTexte = o.Titre.ToLower().Contains(Recherche.ToLower())
                             || o.Entreprise.Nom.ToLower().Contains(Recherche.ToLower());
                bool bonStatut = StatutFiltre == "Tous" || o.Statut.ToString() == StatutFiltre;

                if (bonTexte && bonStatut)
                {
                    Offres.Add(o);
                }
            }
            TexteCompteur = Offres.Count + " offre(s) affichée(s)";
        }

        private void Voir()
        {
            OffreStageModel o = OffreSelectionnee;
            MessageBox.Show(
                "Poste : " + o.Titre + "\n" +
                "Entreprise : " + o.Entreprise.Nom + "\n" +
                "Technologies : " + o.Technologies + "\n" +
                "Durée : " + o.Duree + "\n" +
                "Rémunération : " + o.Remuneration + "\n" +
                "Date limite : " + o.DateLimite.ToString("yyyy-MM-dd") + "\n" +
                "Candidatures : " + o.Candidatures.Count,
                "Détails de l'offre");
        }

        private void Supprimer()
        {
            MessageBoxResult reponse = MessageBox.Show(
                "Supprimer l'offre " + OffreSelectionnee.Titre + " ?",
                "Confirmation", MessageBoxButton.YesNo);

            if (reponse == MessageBoxResult.Yes)
            {
                Donnees.SupprimerOffre(OffreSelectionnee);
                Charger();
            }
        }
    }
}
