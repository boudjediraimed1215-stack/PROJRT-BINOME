using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace GestiCoop.ViewModels
{
    // Classe parent de tous les ViewModels : avertit la Vue quand une propriété change
    public class ViewModelBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string nomPropriete = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(nomPropriete));
            }
        }

        // Change la valeur du champ puis avertit la Vue
        protected void Set<T>(ref T champ, T valeur, [CallerMemberName] string nomPropriete = null)
        {
            champ = valeur;
            OnPropertyChanged(nomPropriete);
        }
    }
}
