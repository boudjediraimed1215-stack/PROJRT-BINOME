// Ce fichier n'est plus utilisé : supprime-le dans Visual Studio
// (clic droit > Supprimer).
