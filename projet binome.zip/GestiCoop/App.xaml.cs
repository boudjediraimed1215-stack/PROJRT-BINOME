using System.Windows;

namespace GestiCoop
{
    public partial class App : Application
    {
    }
}
