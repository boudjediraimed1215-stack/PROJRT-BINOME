namespace GestiCoop.Models
{
    public class EtudiantModel
    {
        public string Prenom { get; set; }
        public string Nom { get; set; }
        public string Matricule { get; set; }
        public string Courriel { get; set; }
        public string Programme { get; set; }

        // Relation 1..n : un étudiant envoie plusieurs candidatures
        public List<CandidatureModel> Candidatures { get; set; } = new List<CandidatureModel>();

        public string NomComplet
        {
            get { return Prenom + " " + Nom; }
        }
    }
}
