namespace GestiCoop.Models
{
    // Le « Type » du diagramme : des valeurs fixes
    public enum StatutEntreprise { Active, Archivée }

    public enum StatutOffre { Ouverte, Fermée }

    public enum StatutCandidature { EnAttente, Acceptée, Refusée }
}
