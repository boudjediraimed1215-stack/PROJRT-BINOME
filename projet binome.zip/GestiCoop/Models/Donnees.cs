namespace GestiCoop.Models
{
    // Les données de l'application (en mémoire, pas de base de données)
    public static class Donnees
    {
        public static List<string> Secteurs = new List<string>
        {
            "Développement logiciel", "Infrastructure Cloud", "Data & IA",
            "Innovation & R&D", "Jeux vidéo", "SaaS / DevOps"
        };

        public static List<EntrepriseModel> Entreprises = new List<EntrepriseModel>();
        public static List<OffreStageModel> Offres = new List<OffreStageModel>();
        public static List<EtudiantModel> Etudiants = new List<EtudiantModel>();
        public static List<CandidatureModel> Candidatures = new List<CandidatureModel>();

        // Ajoute une offre ET la relie à son entreprise (les deux côtés)
        public static void AjouterOffre(EntrepriseModel entreprise, OffreStageModel offre)
        {
            offre.Entreprise = entreprise;
            entreprise.Offres.Add(offre);
            Offres.Add(offre);
        }

        // Crée une candidature entre un étudiant et une offre
        public static void AjouterCandidature(EtudiantModel etudiant, OffreStageModel offre,
                                              DateTime date, StatutCandidature statut)
        {
            CandidatureModel c = new CandidatureModel();
            c.Etudiant = etudiant;
            c.Offre = offre;
            c.DateSoumission = date;
            c.Statut = statut;

            etudiant.Candidatures.Add(c);
            offre.Candidatures.Add(c);
            Candidatures.Add(c);
        }

        public static void SupprimerOffre(OffreStageModel offre)
        {
            foreach (CandidatureModel c in offre.Candidatures)
            {
                c.Etudiant.Candidatures.Remove(c);
                Candidatures.Remove(c);
            }
            offre.Entreprise.Offres.Remove(offre);
            Offres.Remove(offre);
        }

        // Une offre ne peut pas exister sans son entreprise : on supprime aussi ses offres
        public static void SupprimerEntreprise(EntrepriseModel entreprise)
        {
            while (entreprise.Offres.Count > 0)
            {
                SupprimerOffre(entreprise.Offres[0]);
            }
            Entreprises.Remove(entreprise);
        }

        // Données de test (exécuté une seule fois, au premier usage)
        static Donnees()
        {
            EntrepriseModel tech = new EntrepriseModel { Nom = "Tech Solutions Inc.", SiteWeb = "techsolutions.ca", Secteur = "Développement logiciel", ContactNom = "Isabelle Roy", ContactCourriel = "rh@techsolutions.ca", NombrePostes = 3, DateLimite = new DateTime(2025, 11, 30), Statut = StatutEntreprise.Active };
            EntrepriseModel nexus = new EntrepriseModel { Nom = "Nexus Corp", SiteWeb = "nexuscorp.com", Secteur = "Infrastructure Cloud", ContactNom = "Marc-André Lepage", ContactCourriel = "malepage@nexuscorp.com", NombrePostes = 2, DateLimite = new DateTime(2025, 12, 15), Statut = StatutEntreprise.Active };
            EntrepriseModel data = new EntrepriseModel { Nom = "DataViz Labs", SiteWeb = "dataviz.io", Secteur = "Data & IA", ContactNom = "Sophie Chen", ContactCourriel = "schen@dataviz.io", NombrePostes = 4, DateLimite = new DateTime(2025, 11, 1), Statut = StatutEntreprise.Active };
            EntrepriseModel inno = new EntrepriseModel { Nom = "Innolab", SiteWeb = "innolab.ca", Secteur = "Innovation & R&D", ContactNom = "Julien Lavoie", ContactCourriel = "jlavoie@innolab.ca", NombrePostes = 1, DateLimite = new DateTime(2025, 10, 20), Statut = StatutEntreprise.Archivée };
            EntrepriseModel pixel = new EntrepriseModel { Nom = "PixelForge Studio", SiteWeb = "pixelforge.ca", Secteur = "Jeux vidéo", ContactNom = "Nathalie Morin", ContactCourriel = "nmorin@pixelforge.ca", NombrePostes = 2, DateLimite = new DateTime(2025, 12, 1), Statut = StatutEntreprise.Active };
            EntrepriseModel cloud = new EntrepriseModel { Nom = "CloudSync", SiteWeb = "cloudsync.io", Secteur = "SaaS / DevOps", ContactNom = "Alain Bergeron", ContactCourriel = "abergeron@cloudsync.io", NombrePostes = 3, DateLimite = new DateTime(2025, 12, 31), Statut = StatutEntreprise.Active };
            Entreprises.Add(tech);
            Entreprises.Add(nexus);
            Entreprises.Add(data);
            Entreprises.Add(inno);
            Entreprises.Add(pixel);
            Entreprises.Add(cloud);

            OffreStageModel dev = new OffreStageModel { Titre = "Développeur .NET", Technologies = ".NET 8, WPF, SQL", DateLimite = new DateTime(2025, 11, 30), Duree = "1 session", Remuneration = "22 $/h", Statut = StatutOffre.Ouverte };
            OffreStageModel devops = new OffreStageModel { Titre = "Stage DevOps", Technologies = "Docker, Azure, CI/CD", DateLimite = new DateTime(2025, 12, 15), Duree = "2 semestres", Remuneration = "Non rémunéré", Statut = StatutOffre.Ouverte };
            OffreStageModel analyste = new OffreStageModel { Titre = "Analyste données", Technologies = "Python, Power BI", DateLimite = new DateTime(2025, 11, 1), Duree = "1 session", Remuneration = "20 $/h", Statut = StatutOffre.Fermée };
            OffreStageModel full = new OffreStageModel { Titre = "Dev full-stack", Technologies = "React, Node.js, MongoDB", DateLimite = new DateTime(2025, 10, 20), Duree = "1 session", Remuneration = "18 $/h", Statut = StatutOffre.Fermée };
            OffreStageModel jeux = new OffreStageModel { Titre = "Programmeur jeux", Technologies = "Unity, C#", DateLimite = new DateTime(2025, 12, 1), Duree = "1 session", Remuneration = "21 $/h", Statut = StatutOffre.Ouverte };
            AjouterOffre(tech, dev);
            AjouterOffre(nexus, devops);
            AjouterOffre(data, analyste);
            AjouterOffre(inno, full);
            AjouterOffre(pixel, jeux);

            EtudiantModel yasmine = new EtudiantModel { Prenom = "Yasmine", Nom = "Choudhury", Matricule = "20241187", Courriel = "yasmine.c@lacite.edu", Programme = "DECBAC Informatique" };
            EtudiantModel felix = new EtudiantModel { Prenom = "Félix", Nom = "Beaumont", Matricule = "20240942", Courriel = "felix.b@lacite.edu", Programme = "DECBAC Informatique" };
            EtudiantModel lea = new EtudiantModel { Prenom = "Léa", Nom = "Fontaine", Matricule = "20232201", Courriel = "lea.f@lacite.edu", Programme = "Technique en informatique" };
            EtudiantModel karim = new EtudiantModel { Prenom = "Karim", Nom = "Ndiaye", Matricule = "20241053", Courriel = "karim.n@lacite.edu", Programme = "DECBAC Informatique" };
            Etudiants.Add(yasmine);
            Etudiants.Add(felix);
            Etudiants.Add(lea);
            Etudiants.Add(karim);

            AjouterCandidature(yasmine, dev, new DateTime(2025, 10, 12), StatutCandidature.EnAttente);
            AjouterCandidature(felix, devops, new DateTime(2025, 10, 8), StatutCandidature.Acceptée);
            AjouterCandidature(lea, analyste, new DateTime(2025, 10, 5), StatutCandidature.Refusée);
            AjouterCandidature(karim, full, new DateTime(2025, 10, 14), StatutCandidature.EnAttente);
        }
    }
}
