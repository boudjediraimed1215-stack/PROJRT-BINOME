namespace GestiCoop.Models
{
    public class OffreStageModel
    {
        public string Titre { get; set; }
        public string Description { get; set; }
        public string Technologies { get; set; }
        public DateTime DateLimite { get; set; }
        public string Duree { get; set; }
        public string Remuneration { get; set; }
        public StatutOffre Statut { get; set; }

        // Relation 1..1 : une offre appartient à une seule entreprise
        public EntrepriseModel Entreprise { get; set; }

        // Relation 1..n : une offre reçoit plusieurs candidatures
        public List<CandidatureModel> Candidatures { get; set; } = new List<CandidatureModel>();
    }
}
