namespace GestiCoop.Models
{
    // Classe d'association entre un étudiant et une offre
    public class CandidatureModel
    {
        public EtudiantModel Etudiant { get; set; }
        public OffreStageModel Offre { get; set; }

        public DateTime DateSoumission { get; set; }
        public StatutCandidature Statut { get; set; }
    }
}
