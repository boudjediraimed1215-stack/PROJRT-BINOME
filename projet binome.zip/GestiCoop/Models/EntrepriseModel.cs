namespace GestiCoop.Models
{
    public class EntrepriseModel
    {
        public string Nom { get; set; }
        public string SiteWeb { get; set; }
        public string Secteur { get; set; }
        public string Adresse { get; set; }

        // Personne-contact
        public string ContactNom { get; set; }
        public string ContactCourriel { get; set; }
        public string ContactTelephone { get; set; }
        public string ContactTitre { get; set; }

        public int NombrePostes { get; set; }
        public DateTime DateLimite { get; set; }
        public StatutEntreprise Statut { get; set; }

        // Relation 1..n : une entreprise a plusieurs offres
        public List<OffreStageModel> Offres { get; set; } = new List<OffreStageModel>();
    }
}
